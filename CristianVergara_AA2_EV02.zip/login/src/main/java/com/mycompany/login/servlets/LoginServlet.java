
package com.mycompany.login.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usuario = request.getParameter("usuario");
        String contraseña = request.getParameter("contraseña");

        if (usuario == null || contraseña == null || usuario.isEmpty() || contraseña.isEmpty()) {
            response.sendRedirect("index.html");
            return;
        }

        String url = "jdbc:mysql://localhost:3306/servletlogin2";
        String user = "root";
        String password = ""; // Cambia esto si tu base de datos requiere una contraseña

        String query = "SELECT * FROM usuarios WHERE usuario = ? AND contraseña = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            LOGGER.log(Level.SEVERE, "MySQL Driver not found", ex);
            response.sendRedirect("index.html");
            return;
        }

        try (Connection conexion = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setString(1, usuario);
            statement.setString(2, contraseña);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    // Usuario autenticado correctamente
                    request.getSession().setAttribute("usuario", usuario);
                    response.sendRedirect("panel.jsp");
                } else {
                    // Usuario o contraseña incorrectos
                    response.sendRedirect("index.html");
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Database error", ex);
            response.sendRedirect("index.html");
        }
    }
}
